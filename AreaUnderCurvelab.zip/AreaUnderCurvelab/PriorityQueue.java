import java.lang.Math;

public class PriorityQueue {
	private Interval [] heap; // An array that encodes a max-heap data structure.
	private int size;	// The size of allocated buffer for the heap.
	private int numElements;	// The number of elements currently stored. 

	/**
		Constructor: s is the initial size of the heap.
	*/
	public PriorityQueue(int s) {
		size = s;
		heap = new Interval[size + 1];	// 1 extra element allows us to use 1-based indexing. The max heap stores intervals keyed on their lengths.
		numElements = 1;
	}

	/**
		Inserts a new Interval k into the heap. Automatically expands the heap if the buffer allocated is full.
	TODO: Please complete this method.
	*/
	public void insert(Interval k) {
		if (numElements == size) {
			// Expand the buffer allocated for the heap to another buffer that is twice as big.
	        size = size * 2;
            Interval[] newHeap = new Interval[size];
            for (int i=0; i < numElements; i++) {
                newHeap[i] = heap[i];
            }
            heap = newHeap;
    	}
		// Insert without buffer expansion here.
            heap[numElements] = k;
            siftUp(numElements);
            numElements++;
    }

    private void siftUp(int index) {
        Integer parent;
        Interval tmp;
        if (index != 1) {
            parent = getParent(index);
            if (heap[index].compareTo(heap[parent]) > 0) {
                tmp = heap[parent];
                heap[parent] = heap[index];
                heap[index] = tmp;
                siftUp(parent);
            }
        }
    }
    public Integer getParent(Integer index) {
        return (int) (index/2);
    }
 
    public Integer getLeft(Integer index) {
        return (2 * index);
    }

    public Integer getRight(Integer index) {
        return (2 * index) + 1;
    }
    public int getNumElements()
    {
        return numElements;
    }

	/**
		Returns the maximum Interval from the heap (usually the one with the largest length. See the compareTo function of Interval for more details on the comparison.
	TODO: Please complete this method.
	*/
	public Interval remove_max() {
		if (numElements == 1) return null; // Retuns null if heap is empty.
        else if (numElements == 2) {
            Interval tmp = heap[1];
            heap[1] = heap[numElements - 1];
            heap[numElements -1] = null;
            numElements--;
            return tmp;
        }
		// Remove_max code here.
	    else if (numElements > 2) {
            Interval tmp1 = heap[1];
            heap[1] = heap[numElements-1];
            heap[numElements-1] = null;
            numElements--;
            siftDown(1);
	    	return tmp1; // Replace this statement with returning the max element (root) in the heap.
        }
        else return null;
	}
    public Interval getI(int index) {
        return heap[index];
    }

    private void siftDown(Integer index) {
        int left = getLeft(index);
        int right = getRight(index);
        Interval tmp;
        if (left >= 1 && left < numElements && right >= 1 && right < numElements &&  heap[left] != null && heap[right] != null) {
            if (heap[index].compareTo(heap[left]) < 0){
                if (heap[index].compareTo(heap[right]) < 0) {
                    if (heap[left].compareTo(heap[right]) > 0){
                        tmp = heap[left];
                        heap[left] = heap[index];
                        heap[index] = tmp;
                        siftDown(left);
                    }
                    else {
                       tmp = heap[right];
                       heap[right] = heap[index];
                       heap[index] = tmp;
                       siftDown(right);
                    }
                }
                else {
                   tmp = heap[left];
                   heap[left] = heap[index];
                   heap[index] = tmp;  
                   siftDown(left); 
                }
            }
            else if (heap[index].compareTo(heap[right]) < 0)
            {
                tmp = heap[right];
                heap[right] = heap[index];
                heap[index] = tmp;
                siftDown(right);
            }
        }
        else if (left >= 1 && left < numElements && heap[left] != null)
        {
            if (heap[index].compareTo(heap[left]) < 0) {
                tmp = heap[left];
                heap[left] = heap[index];
                heap[index] = tmp;
                siftDown(left);
            }
        }
        else if (right >= 1 && right < numElements && heap[right] != null)
        {
            if (heap[index].compareTo(heap[right]) < 0) {
                tmp = heap[right];
                heap[right] = heap[index];
                heap[index] = tmp;
                siftDown(right);
            }
        }
    }

	/**
		This function prints the contents of the array that encodes a heap.
	*/
	public void print() {
		System.out.println("Printing heap:");
		for (int i = 1; i < numElements; ++i)
			System.out.println(heap[i]);
	}
}
