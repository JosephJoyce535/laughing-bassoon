public class PQTest {
    public static void main(String[] args) {
        PriorityQueue pq = new PriorityQueue(3);
        Interval i1 = new Interval(0, 2);
        Interval i2 = new Interval(0, 3.5);
        Interval i3 = new Interval(-4, 8.9);
        Interval i4 = new Interval(0, 8.2);
        Interval i5 = new Interval(-1, 1.6);
        pq.insert(i1);
        System.out.println("Now deleting only Interval");
        Interval mn = pq.remove_max();
        double p = (mn.getStart() + mn.getEnd())/2;
        Interval mp = new Interval(mn.getStart(), p);
        Interval pn = new Interval(p, mn.getEnd());
        pq.insert(mp);
        pq.insert(pn);
       // pq.insert(i4);
       // pq.insert(i5);
        pq.print();
        System.out.println("Now deleting largest Interval");
        pq.remove_max();
        pq.print();
    }
}
